package com.ewns.restoran;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Admin_panel extends AppCompatActivity {

    private Toolbar actionbaradmin;
    private TabsAdapter tabsAdapter;
    private ViewPager viewPager;
    private TabLayout tabLayout;


    public void init(){
        actionbaradmin=findViewById(R.id.actionbarAdmin);
        setSupportActionBar(actionbaradmin);
        getSupportActionBar().setTitle("Admin Panel");


        viewPager=findViewById(R.id.vpMain);
        tabsAdapter=new TabsAdapter(getSupportFragmentManager());
        viewPager.setAdapter(tabsAdapter);

        tabLayout=findViewById(R.id.tabsMain);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_panel);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_masa :
                Intent i=new Intent(this,MasaActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
               // Toast.makeText(getApplicationContext(),"Masa",Toast.LENGTH_LONG).show();
            return true;
            case R.id.action_cikis :
                Intent i2=new Intent(this,StartActivity.class);
                i2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i2);
            //    Toast.makeText(getApplicationContext(),"Çıkış",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
