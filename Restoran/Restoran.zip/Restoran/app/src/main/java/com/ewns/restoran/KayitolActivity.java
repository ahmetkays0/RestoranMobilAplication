package com.ewns.restoran;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.EditText;

public class KayitolActivity extends AppCompatActivity {

    private Toolbar actionbarKayitol;
    private EditText edit_ad,edit_email,edit_sifre;
    private Button btn_olustur;
    //FirebaseAuth yetki;

    public void init(){
        actionbarKayitol=findViewById(R.id.actionbarKayitol);
        setSupportActionBar(actionbarKayitol);
        getSupportActionBar().setTitle("Hesap Oluştur");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kayitol);
        init();

        edit_ad=findViewById(R.id.edit_ad);
        edit_email=findViewById(R.id.edit_email);
        edit_sifre=findViewById(R.id.edit_sifre);
        btn_olustur=findViewById(R.id.btn_olustur);

    }
}
