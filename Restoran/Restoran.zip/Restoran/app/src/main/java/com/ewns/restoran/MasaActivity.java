package com.ewns.restoran;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;

public class MasaActivity extends AppCompatActivity {

    private Toolbar actionbarmasa;

    public void init(){
        actionbarmasa=findViewById(R.id.actionbarMasalar);
        setSupportActionBar(actionbarmasa);
        getSupportActionBar().setTitle("Masalar");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private RecyclerView rv;
    private ArrayList<String> masalarList;
    private MasaRVAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();


        rv=findViewById(R.id.rv);
        rv.setHasFixedSize(true);

       // rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setLayoutManager(new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL));
    masalarList=new ArrayList<>();
    masalarList.add("Masa1");
        masalarList.add("Masa2");
        masalarList.add("Masa3");
        masalarList.add("Masa1Kat2");
        masalarList.add("Masa2Kat2");


        adapter=new MasaRVAdapter(this,masalarList);

        rv.setAdapter(adapter);

    }
}

