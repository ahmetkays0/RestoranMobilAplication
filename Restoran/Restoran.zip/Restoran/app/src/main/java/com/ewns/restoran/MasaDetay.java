package com.ewns.restoran;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class MasaDetay extends AppCompatActivity {


    private Toolbar actionbarMasaDetay;
    private String masaismi;

    public void init(){
        actionbarMasaDetay =findViewById(R.id.actionbarMasaDetay);
        setSupportActionBar(actionbarMasaDetay);
        getSupportActionBar().setTitle(masaismi);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masa_detay);

        masaismi=(String)getIntent().getSerializableExtra("nesne");

        init();
    }
}
