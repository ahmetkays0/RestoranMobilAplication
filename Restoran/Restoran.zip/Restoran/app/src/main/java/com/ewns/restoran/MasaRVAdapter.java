package com.ewns.restoran;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.content.*;


import java.util.List;

public class MasaRVAdapter extends RecyclerView.Adapter<MasaRVAdapter.CardViewTasarimNesneleriniTutucu> {
    private Context mContext;
    private List<String> masaisimleriList;

    public MasaRVAdapter(Context mContext, List<String> masaisimleriList) {
        this.mContext = mContext;
        this.masaisimleriList = masaisimleriList;
    }


    public class CardViewTasarimNesneleriniTutucu extends RecyclerView.ViewHolder{

        public TextView masaismiTxt;
        public CardView lineCardView;

        public CardViewTasarimNesneleriniTutucu(View view){
            super(view);

            masaismiTxt=view.findViewById(R.id.masaisim);
            lineCardView=view.findViewById(R.id.satirCardView);

        }
    }


    @NonNull
    @Override
    public CardViewTasarimNesneleriniTutucu onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView=LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.card_tasarim,viewGroup,false);


        return new CardViewTasarimNesneleriniTutucu(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewTasarimNesneleriniTutucu holder, int i) {

        final String masa= masaisimleriList.get(i);

        holder.masaismiTxt.setText(masa);

        holder.masaismiTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(mContext,"Seçtiğiniz Masa: "+masa,Toast.LENGTH_LONG).show();
                Intent intent=new Intent(mContext,MasaDetay.class);
                intent.putExtra("nesne",masa);
                mContext.startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return masaisimleriList.size();
    }




}
