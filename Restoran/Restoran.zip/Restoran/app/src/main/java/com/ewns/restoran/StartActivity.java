package com.ewns.restoran;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class StartActivity extends AppCompatActivity {

    EditText EmailET,sifreET;
    Button girisBTN;
    TextView kayitTV;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        EmailET=findViewById(R.id.EmailET);
        sifreET=findViewById(R.id.sifreET);
        girisBTN=findViewById(R.id.girisyapBTN);
        kayitTV=findViewById(R.id.kayitTV);




        girisBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(StartActivity.this,Admin_panel.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        kayitTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(StartActivity.this,KayitolActivity.class);
                startActivity(intent);
            }
        });

    }
}
