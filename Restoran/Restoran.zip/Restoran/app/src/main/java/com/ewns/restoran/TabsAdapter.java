package com.ewns.restoran;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class TabsAdapter extends FragmentPagerAdapter {

    public TabsAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {

        switch (i){
            case 0:
                masaFragment masaFragment=new masaFragment();
                return masaFragment;

            case 1:
                UrunFragment urunFragment =new UrunFragment();
                return urunFragment;

            case 2:
                CalisanFragment calisanFragment=new CalisanFragment();
                return calisanFragment;

                default:
                    return null;
        }


    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int i) {
        switch (i){
            case 0:

                return "Masalar";

            case 1:

                return "Ürünler";

            case 2:
              return "Çalışanlar";



            default:
                return null;
        }

    }
}
